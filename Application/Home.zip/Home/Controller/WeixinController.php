<?php
namespace Home\Controller;

use Think\Controller;

class WeixinController extends Controller{
    
}