<?php
return array(
	//'配置项'=>'配置值'
	'APPID'         =>  'wx048e799c033d8b96',
    'APP_SECRETE'    =>  'b400c0305206424d71ee100a1a9aa88e',
);